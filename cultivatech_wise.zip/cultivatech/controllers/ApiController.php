<?php
declare(strict_types=1);

final class ApiController extends Controller
{
    /**
     * GET api/dashboard.php
     * Resumen en JSON para refrescar el panel (requiere sesión iniciada).
     */
    public function summary(): void
    {
        if (!Session::check()) {
            $this->json(['ok' => false, 'error' => 'No autenticado.'], 401);
        }

        $user = Session::user();
        // Se libera el bloqueo de sesión antes de consultar la base de datos
        session_write_close();

        $this->json(['ok' => true] + SensorReading::summary((int) $user['id']));
    }

    /**
     * POST api/lecturas.php
     * Recibe una lectura desde el dispositivo (ESP32, Arduino, etc.).
     *
     * Autenticación: cabecera "X-API-Key: <clave>" (o campo api_key).
     * Cuerpo: JSON o formulario con temperatura, humedad_ambiente,
     *         humedad_suelo y co2.
     */
    public function ingest(): void
    {
        if (!$this->isPost()) {
            header('Allow: POST');
            $this->json(['ok' => false, 'error' => 'Método no permitido. Usa POST.'], 405);
        }

        $raw  = (string) file_get_contents('php://input');
        $body = [];
        if (str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) {
                $this->json(['ok' => false, 'error' => 'JSON inválido.'], 400);
            }
            $body = $decoded;
        } else {
            $body = $_POST;
        }

        $apiKey = (string) ($_SERVER['HTTP_X_API_KEY'] ?? $body['api_key'] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/', $apiKey)) {
            $this->json(['ok' => false, 'error' => 'Clave API ausente o con formato inválido.'], 401);
        }

        $user = User::findByApiKey($apiKey);
        if ($user === null) {
            $this->json(['ok' => false, 'error' => 'Clave API no reconocida.'], 401);
        }

        $values = [];
        foreach (SENSOR_LIMITS as $field => [$min, $max]) {
            $v = $body[$field] ?? null;
            if (!is_numeric($v)) {
                $this->json(['ok' => false, 'error' => "El campo {$field} es obligatorio y debe ser numérico."], 422);
            }
            $v = (float) $v;
            if ($v < $min || $v > $max) {
                $this->json(['ok' => false, 'error' => "El campo {$field} está fuera del rango permitido ({$min} a {$max})."], 422);
            }
            $values[$field] = $v;
        }

        $id = SensorReading::insert(
            (int) $user['id'],
            round($values['temperatura'], 2),
            round($values['humedad_ambiente'], 2),
            round($values['humedad_suelo'], 2),
            (int) round($values['co2'])
        );

        $this->json(['ok' => true, 'id' => $id], 201);
    }
}
