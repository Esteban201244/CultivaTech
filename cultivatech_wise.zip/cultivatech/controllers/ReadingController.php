<?php
declare(strict_types=1);

/**
 * CRUD de lecturas desde el dashboard.
 * Todas las acciones exigen sesión, método POST y token CSRF, y solo
 * operan sobre las lecturas del usuario autenticado.
 */
final class ReadingController extends Controller
{
    /** Valida acceso y devuelve el usuario. */
    private function guard(): array
    {
        $user = $this->requireAuth();

        if (!$this->isPost()) {
            $this->redirect('dashboard.php');
        }
        if (!Session::verifyCsrf($_POST['csrf'] ?? null)) {
            Session::flash('error', 'La sesión del formulario expiró. Intenta de nuevo.');
            $this->back();
        }
        return $user;
    }

    /** Vuelve al dashboard, a la misma página de la tabla. */
    private function back(): never
    {
        $page = max(1, (int) ($_POST['page'] ?? 1));
        $this->redirect('dashboard.php' . ($page > 1 ? '?page=' . $page : '') . '#lecturas');
    }

    /** CREATE */
    public function store(): void
    {
        $user   = $this->guard();
        $result = SensorReading::validate($_POST);

        if ($result['errors']) {
            Session::flash('error', implode(' ', $result['errors']));
            $this->back();
        }

        $d = $result['data'];
        SensorReading::insert(
            (int) $user['id'],
            round($d['temperatura'], 2),
            round($d['humedad_ambiente'], 2),
            round($d['humedad_suelo'], 2),
            (int) round($d['co2']),
            $d['fecha']
        );

        Session::flash('ok', 'Lectura agregada.');
        $_POST['page'] = 1; // las más recientes aparecen en la primera página
        $this->back();
    }

    /** UPDATE */
    public function update(): void
    {
        $user = $this->guard();
        $id   = (int) ($_POST['id'] ?? 0);
        $row  = $id > 0 ? SensorReading::find((int) $user['id'], $id) : null;

        if ($row === null) {
            Session::flash('error', 'Esa lectura ya no existe.');
            $this->back();
        }

        $result = SensorReading::validate($_POST, $row['registrado_en']);
        if ($result['errors']) {
            Session::flash('error', implode(' ', $result['errors']));
            $this->back();
        }

        SensorReading::update((int) $user['id'], $id, $result['data']);

        Session::flash('ok', 'Lectura actualizada.');
        $this->back();
    }

    /** DELETE (una lectura) */
    public function destroy(): void
    {
        $user = $this->guard();
        $id   = (int) ($_POST['id'] ?? 0);

        if ($id > 0 && SensorReading::delete((int) $user['id'], $id)) {
            Session::flash('ok', 'Lectura eliminada.');
        } else {
            Session::flash('error', 'Esa lectura ya no existe.');
        }
        $this->back();
    }

    /** DELETE (todas las lecturas del usuario) */
    public function destroyAll(): void
    {
        $user    = $this->guard();
        $deleted = SensorReading::deleteAll((int) $user['id']);

        Session::flash('ok', $deleted === 1 ? 'Se eliminó 1 lectura.' : "Se eliminaron {$deleted} lecturas.");
        $_POST['page'] = 1;
        $this->back();
    }
}
