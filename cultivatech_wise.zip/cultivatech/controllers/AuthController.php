<?php
declare(strict_types=1);

final class AuthController extends Controller
{
    /* ---------------- LOGIN ---------------- */

    public function login(): void
    {
        $this->requireGuest();

        if (!$this->isPost()) {
            $this->render('auth/login', ['errors' => [], 'old' => ['email' => '']]);
            return;
        }

        $email    = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $errors   = [];

        if (!Session::verifyCsrf($_POST['csrf'] ?? null)) {
            $errors[] = 'La sesión del formulario expiró. Intenta de nuevo.';
        } elseif (($wait = Session::loginLockedFor()) > 0) {
            $errors[] = "Demasiados intentos fallidos. Espera {$wait} segundos para volver a intentar.";
        } else {
            $user = User::findByEmail($email);

            // Se verifica siempre un hash para no revelar por tiempo si el correo existe
            $hash = $user['password_hash'] ?? '$2y$10$usesomesillystringforsaltuusesomesillystringforsaltu12';
            $ok   = password_verify($password, $hash) && $user !== null;

            if ($ok) {
                Session::clearLoginFailures();
                if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
                    User::updatePasswordHash((int) $user['id'], $password);
                }
                Session::login($user);
                $this->redirect('dashboard.php');
            }

            Session::registerLoginFailure();
            $errors[] = 'Correo o contraseña incorrectos.';
        }

        $this->render('auth/login', ['errors' => $errors, 'old' => ['email' => $email]]);
    }

    /* ---------------- REGISTRO ---------------- */

    public function register(): void
    {
        $this->requireGuest();

        if (!$this->isPost()) {
            $this->render('auth/register', ['errors' => [], 'old' => ['nombre' => '', 'email' => '']]);
            return;
        }

        $nombre   = trim((string) ($_POST['nombre'] ?? ''));
        $email    = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $confirm  = (string) ($_POST['password_confirm'] ?? '');
        $errors   = [];

        if (!Session::verifyCsrf($_POST['csrf'] ?? null)) {
            $errors[] = 'La sesión del formulario expiró. Intenta de nuevo.';
        }

        $len = mb_strlen($nombre);
        if ($len < 2 || $len > 80) {
            $errors[] = 'Escribe tu nombre (entre 2 y 80 caracteres).';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
            $errors[] = 'Escribe un correo electrónico válido.';
        }
        if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
            $errors[] = 'La contraseña debe tener mínimo 8 caracteres, con letras y números.';
        }
        if ($password !== $confirm) {
            $errors[] = 'Las contraseñas no coinciden.';
        }

        if (!$errors) {
            try {
                $id   = User::create($nombre, $email, $password);
                $user = User::findById($id);
                Session::login($user);
                $this->redirect('dashboard.php');
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') {
                    $errors[] = 'Ya existe una cuenta con ese correo. Inicia sesión.';
                } else {
                    throw $e;
                }
            }
        }

        $this->render('auth/register', ['errors' => $errors, 'old' => ['nombre' => $nombre, 'email' => $email]]);
    }

    /* ---------------- LOGOUT ---------------- */

    public function logout(): void
    {
        // Solo por POST con token CSRF, para que otro sitio no pueda cerrar la sesión
        if ($this->isPost() && Session::verifyCsrf($_POST['csrf'] ?? null)) {
            Session::logout();
        }
        $this->redirect($this->isPost() ? 'login.php' : 'dashboard.php');
    }
}
