<?php
declare(strict_types=1);

final class DashboardController extends Controller
{
    private const PER_PAGE = 10;

    public function index(): void
    {
        $user    = $this->requireAuth();
        $account = User::findById((int) $user['id']);

        if ($account === null) {
            // La cuenta ya no existe: se cierra la sesión
            Session::logout();
            $this->redirect('login.php');
        }

        $page = max(1, (int) ($_GET['page'] ?? 1));

        $this->render('dashboard', [
            'user'     => $user,
            'apiKey'   => $account['api_key'],
            'summary'  => SensorReading::summary((int) $user['id']),
            'readings' => SensorReading::paginate((int) $user['id'], $page, self::PER_PAGE),
            'flash'    => Session::pullFlash(),
            'nowInput' => date('Y-m-d\TH:i'),
            'endpoint' => absolute_url('api/lecturas.php'),
            'live'     => absolute_url('api/dashboard.php'),
        ]);
    }

    /** Carga lecturas simuladas, solo si la cuenta aún no tiene ninguna. */
    public function loadDemo(): void
    {
        $user = $this->requireAuth();

        if ($this->isPost() && Session::verifyCsrf($_POST['csrf'] ?? null)) {
            if (SensorReading::count((int) $user['id']) === 0) {
                SensorReading::seedDemo((int) $user['id']);
            }
        }

        $this->redirect('dashboard.php');
    }
}
