<?php
declare(strict_types=1);

final class SensorReading
{
    private const COLUMNS = ['temperatura', 'humedad_ambiente', 'humedad_suelo', 'co2'];

    /** Cantidad de lecturas usadas para gráficas y estadísticas. */
    private const WINDOW = 48;

    public static function insert(int $userId, float $temp, float $humAir, float $humSoil, int $co2, ?string $when = null): int
    {
        $pdo  = Database::connection();
        $stmt = $pdo->prepare(
            'INSERT INTO lecturas_sensores
                (usuario_id, temperatura, humedad_ambiente, humedad_suelo, co2, registrado_en)
             VALUES (:u, :t, :ha, :hs, :co2, :fecha)'
        );
        $stmt->execute([
            'u'     => $userId,
            't'     => $temp,
            'ha'    => $humAir,
            'hs'    => $humSoil,
            'co2'   => $co2,
            'fecha' => $when ?? date('Y-m-d H:i:s'),
        ]);
        return (int) $pdo->lastInsertId();
    }

    public static function count(int $userId): int
    {
        $stmt = Database::connection()->prepare('SELECT COUNT(*) FROM lecturas_sensores WHERE usuario_id = :u');
        $stmt->execute(['u' => $userId]);
        return (int) $stmt->fetchColumn();
    }

    /** Últimas N lecturas, de la más antigua a la más reciente. */
    public static function series(int $userId, int $limit = self::WINDOW): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM (
                SELECT id, temperatura, humedad_ambiente, humedad_suelo, co2, registrado_en
                FROM lecturas_sensores
                WHERE usuario_id = :u
                ORDER BY registrado_en DESC, id DESC
                LIMIT :n
             ) AS ultimas
             ORDER BY registrado_en ASC, id ASC'
        );
        $stmt->bindValue(':u', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':n', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** Clasifica un valor: optimo | atencion | critico | sin_datos */
    public static function evaluate(string $key, ?float $value): string
    {
        if ($value === null || !isset(SENSORS[$key])) {
            return 'sin_datos';
        }
        [$oMin, $oMax] = SENSORS[$key]['optimo'];
        [$aMin, $aMax] = SENSORS[$key]['aceptable'];

        if ($value >= $oMin && $value <= $oMax) {
            return 'optimo';
        }
        if ($value >= $aMin && $value <= $aMax) {
            return 'atencion';
        }
        return 'critico';
    }

    public static function statusLabel(string $status): string
    {
        return match ($status) {
            'optimo'   => 'Óptimo',
            'atencion' => 'Atención',
            'critico'  => 'Crítico',
            default    => 'Sin datos',
        };
    }

    private static function fmt(?float $v, int $decimals): string
    {
        return $v === null ? '--' : number_format($v, $decimals, ',', '.');
    }

    /**
     * Resumen listo para la vista y para la API del dashboard:
     * una entrada por métrica (valor actual, estado, mín/máx/promedio, serie)
     * y la tabla de lecturas recientes.
     */
    public static function summary(int $userId): array
    {
        $serie = self::series($userId);
        $last  = $serie ? $serie[array_key_last($serie)] : null;

        $metrics = [];
        foreach (SENSORS as $key => $def) {
            $values = array_map(static fn(array $r): float => (float) $r[$key], $serie);
            $value  = $last ? (float) $last[$key] : null;
            $status = self::evaluate($key, $value);
            $d      = $def['decimals'];

            $metrics[] = [
                'key'          => $key,
                'label'        => $def['label'],
                'unit'         => $def['unit'],
                'value'        => $value,
                'display'      => self::fmt($value, $d),
                'status'       => $status,
                'status_label' => self::statusLabel($status),
                'min'          => self::fmt($values ? min($values) : null, $d),
                'max'          => self::fmt($values ? max($values) : null, $d),
                'avg'          => self::fmt($values ? array_sum($values) / count($values) : null, $d),
                'range_text'   => sprintf(
                    'Rango óptimo: %s–%s %s',
                    number_format($def['optimo'][0], 0, ',', '.'),
                    number_format($def['optimo'][1], 0, ',', '.'),
                    $def['unit']
                ),
                'series'       => $values,
            ];
        }

        return [
            'has_data'      => $last !== null,
            'updated_at'    => $last ? date('c', strtotime($last['registrado_en'])) : null,
            'updated_label' => $last ? date('d/m/Y H:i', strtotime($last['registrado_en'])) : null,
            'total'         => self::count($userId),
            'metrics'       => $metrics,
        ];
    }

    /**
     * Genera 48 lecturas simuladas (una cada 30 min) para probar el panel
     * sin tener todavía un dispositivo conectado.
     */
    public static function seedDemo(int $userId): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $now = time();
            for ($i = self::WINDOW - 1; $i >= 0; $i--) {
                $ts   = $now - $i * 1800;
                $hour = (int) date('G', $ts) + (int) date('i', $ts) / 60;
                $wave = sin(2 * M_PI * ($hour - 9) / 24);

                $temp = 24.5 + 5.5 * $wave + self::noise(0.4);
                $hAir = 67.0 - 11.0 * $wave + self::noise(1.2);
                $soil = 62.0 - (self::WINDOW - 1 - $i) * 0.12 + ($i % 20 === 0 ? 9 : 0) + self::noise(0.8);
                $co2  = 560 + 140 * $wave + ($i % 13 === 0 ? 260 : 0) + self::noise(25);

                self::insert(
                    $userId,
                    round(max(-40, min(80, $temp)), 2),
                    round(max(0, min(100, $hAir)), 2),
                    round(max(0, min(100, $soil)), 2),
                    (int) max(250, min(10000, $co2)),
                    date('Y-m-d H:i:s', $ts)
                );
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function noise(float $amplitude): float
    {
        return (mt_rand(-1000, 1000) / 1000) * $amplitude;
    }

    /* ============================================================
       CRUD de lecturas (siempre acotado al usuario dueño)
       ============================================================ */

    /** Página de lecturas (más recientes primero) lista para la tabla. */
    public static function paginate(int $userId, int $page, int $perPage = 10): array
    {
        $total = self::count($userId);
        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $stmt = Database::connection()->prepare(
            'SELECT id, temperatura, humedad_ambiente, humedad_suelo, co2, registrado_en
             FROM lecturas_sensores
             WHERE usuario_id = :u
             ORDER BY registrado_en DESC, id DESC
             LIMIT :n OFFSET :o'
        );
        $stmt->bindValue(':u', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':n', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':o', ($page - 1) * $perPage, PDO::PARAM_INT);
        $stmt->execute();

        $rows = array_map([self::class, 'present'], $stmt->fetchAll());

        return ['rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages];
    }

    /** Una fila lista para mostrar y para precargar el formulario de edición. */
    private static function present(array $r): array
    {
        $ts  = strtotime($r['registrado_en']);
        $out = [
            'id'          => (int) $r['id'],
            'fecha_label' => date('d/m/Y H:i', $ts),
            'fecha_input' => date('Y-m-d\TH:i', $ts),
        ];
        foreach (self::COLUMNS as $col) {
            $v = (float) $r[$col];
            $out[$col] = [
                'display' => self::fmt($v, SENSORS[$col]['decimals']),
                'raw'     => rtrim(rtrim(number_format($v, 2, '.', ''), '0'), '.'),
                'status'  => self::evaluate($col, $v),
            ];
        }
        return $out;
    }

    public static function find(int $userId, int $id): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT id, temperatura, humedad_ambiente, humedad_suelo, co2, registrado_en
             FROM lecturas_sensores WHERE id = :id AND usuario_id = :u LIMIT 1'
        );
        $stmt->execute(['id' => $id, 'u' => $userId]);
        return $stmt->fetch() ?: null;
    }

    /** @param array{temperatura:float,humedad_ambiente:float,humedad_suelo:float,co2:float,fecha:string} $data */
    public static function update(int $userId, int $id, array $data): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE lecturas_sensores
             SET temperatura = :t, humedad_ambiente = :ha, humedad_suelo = :hs,
                 co2 = :co2, registrado_en = :fecha
             WHERE id = :id AND usuario_id = :u'
        );
        $stmt->execute([
            't'     => round($data['temperatura'], 2),
            'ha'    => round($data['humedad_ambiente'], 2),
            'hs'    => round($data['humedad_suelo'], 2),
            'co2'   => (int) round($data['co2']),
            'fecha' => $data['fecha'],
            'id'    => $id,
            'u'     => $userId,
        ]);
    }

    public static function delete(int $userId, int $id): bool
    {
        $stmt = Database::connection()->prepare(
            'DELETE FROM lecturas_sensores WHERE id = :id AND usuario_id = :u'
        );
        $stmt->execute(['id' => $id, 'u' => $userId]);
        return $stmt->rowCount() > 0;
    }

    public static function deleteAll(int $userId): int
    {
        $stmt = Database::connection()->prepare('DELETE FROM lecturas_sensores WHERE usuario_id = :u');
        $stmt->execute(['u' => $userId]);
        return $stmt->rowCount();
    }

    /**
     * Valida los datos de un formulario de lectura.
     * Si la fecha viene vacía se usa $defaultDate (o la hora actual).
     *
     * @return array{data: array, errors: string[]}
     */
    public static function validate(array $input, ?string $defaultDate = null): array
    {
        $errors = [];
        $data   = [];

        foreach (SENSOR_LIMITS as $field => [$min, $max]) {
            $label = SENSORS[$field]['label'];
            $unit  = SENSORS[$field]['unit'];
            $raw   = str_replace(',', '.', trim((string) ($input[$field] ?? '')));

            if ($raw === '' || !is_numeric($raw)) {
                $errors[] = "{$label}: escribe un número.";
                continue;
            }
            $value = (float) $raw;
            if ($value < $min || $value > $max) {
                $errors[] = "{$label} debe estar entre {$min} y {$max} {$unit}.";
                continue;
            }
            $data[$field] = $value;
        }

        $tz      = new DateTimeZone(date_default_timezone_get());
        $rawDate = trim((string) ($input['fecha'] ?? ''));

        if ($rawDate === '') {
            $data['fecha'] = $defaultDate ?? date('Y-m-d H:i:s');
        } else {
            $dt = DateTime::createFromFormat('Y-m-d\TH:i', $rawDate, $tz)
                ?: DateTime::createFromFormat('Y-m-d\TH:i:s', $rawDate, $tz);

            if ($dt === false) {
                $errors[] = 'La fecha y hora no tienen un formato válido.';
            } elseif ($dt->getTimestamp() > time() + 300) {
                $errors[] = 'La fecha de la lectura no puede estar en el futuro.';
            } else {
                $data['fecha'] = $dt->format('Y-m-d H:i:s');
            }
        }

        return ['data' => $data, 'errors' => $errors];
    }
}
