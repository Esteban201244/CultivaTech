<?php
declare(strict_types=1);

final class User
{
    public static function findByEmail(string $email): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT id, nombre, email, password_hash, api_key FROM usuarios WHERE email = :email LIMIT 1'
        );
        $stmt->execute(['email' => $email]);
        return $stmt->fetch() ?: null;
    }

    public static function findById(int $id): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT id, nombre, email, api_key FROM usuarios WHERE id = :id LIMIT 1'
        );
        $stmt->execute(['id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function findByApiKey(string $apiKey): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT id, nombre, email FROM usuarios WHERE api_key = :k LIMIT 1'
        );
        $stmt->execute(['k' => $apiKey]);
        return $stmt->fetch() ?: null;
    }

    public static function emailExists(string $email): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM usuarios WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => $email]);
        return (bool) $stmt->fetchColumn();
    }

    /**
     * Crea el usuario con contraseña cifrada y una clave API única.
     * Devuelve el id nuevo. Lanza PDOException (código 23000) si el email ya existe.
     */
    public static function create(string $nombre, string $email, string $password): int
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare(
            'INSERT INTO usuarios (nombre, email, password_hash, api_key)
             VALUES (:nombre, :email, :hash, :api_key)'
        );
        $stmt->execute([
            'nombre'  => $nombre,
            'email'   => $email,
            'hash'    => password_hash($password, PASSWORD_DEFAULT),
            'api_key' => bin2hex(random_bytes(32)),
        ]);
        return (int) $pdo->lastInsertId();
    }

    public static function updatePasswordHash(int $id, string $password): void
    {
        $stmt = Database::connection()->prepare('UPDATE usuarios SET password_hash = :h WHERE id = :id');
        $stmt->execute(['h' => password_hash($password, PASSWORD_DEFAULT), 'id' => $id]);
    }
}
