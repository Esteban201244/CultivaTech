<?php
declare(strict_types=1);

/**
 * Manejo de sesión, autenticación y tokens CSRF.
 */
final class Session
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

        session_name('cultivatech_sid');
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => $https,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    public static function login(array $user): void
    {
        self::start();
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'     => (int) $user['id'],
            'nombre' => (string) $user['nombre'],
            'email'  => (string) $user['email'],
        ];
    }

    public static function check(): bool
    {
        self::start();
        return isset($_SESSION['user']['id']);
    }

    public static function user(): ?array
    {
        self::start();
        return $_SESSION['user'] ?? null;
    }

    public static function logout(): void
    {
        self::start();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires'  => time() - 42000,
                'path'     => $p['path'],
                'domain'   => $p['domain'],
                'secure'   => $p['secure'],
                'httponly' => $p['httponly'],
                'samesite' => $p['samesite'] ?: 'Lax',
            ]);
        }
        session_destroy();
    }

    /* ---------- Mensajes flash (se muestran una sola vez) ---------- */

    public static function flash(string $type, string $message): void
    {
        self::start();
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }

    public static function pullFlash(): ?array
    {
        self::start();
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $flash;
    }

    /* ---------- CSRF ---------- */

    public static function csrfToken(): string
    {
        self::start();
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    public static function verifyCsrf(?string $token): bool
    {
        self::start();
        return is_string($token)
            && isset($_SESSION['csrf'])
            && hash_equals($_SESSION['csrf'], $token);
    }

    /* ---------- Límite de intentos de login ---------- */

    public static function loginLockedFor(): int
    {
        self::start();
        $until = $_SESSION['login_lock_until'] ?? 0;
        return max(0, $until - time());
    }

    public static function registerLoginFailure(): void
    {
        self::start();
        $_SESSION['login_failures'] = ($_SESSION['login_failures'] ?? 0) + 1;
        if ($_SESSION['login_failures'] >= 5) {
            $_SESSION['login_lock_until'] = time() + 60;
            $_SESSION['login_failures']   = 0;
        }
    }

    public static function clearLoginFailures(): void
    {
        self::start();
        unset($_SESSION['login_failures'], $_SESSION['login_lock_until']);
    }
}
