<?php
declare(strict_types=1);

/** Escapa texto para imprimir en HTML. */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** URL relativa al proyecto: url('login.php') => /cultivatech/login.php */
function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/** URL de un recurso estático con versión para evitar caché obsoleta. */
function asset(string $path): string
{
    $file = dirname(__DIR__) . '/assets/' . ltrim($path, '/');
    $v = is_file($file) ? '?v=' . filemtime($file) : '';
    return url('assets/' . ltrim($path, '/')) . $v;
}

/** URL absoluta (para mostrar el endpoint de la API al usuario). */
function absolute_url(string $path = ''): string
{
    $https  = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ($https ? 'https://' : 'http://') . $host . url($path);
}

/**
 * URL de una foto de cultivos (Unsplash, licencia libre, sin atribución obligatoria).
 * Las fotos se cargan desde images.unsplash.com con el ancho pedido.
 */
function photo(string $key, int $width = 1200): string
{
    static $ids = [
        'semillero' => 'photo-1523348837708-15d4a09cfac2', // plántulas en macetas negras
        'manos'     => 'photo-1542601906990-b4d3fb778b09', // manos sosteniendo una plántula
        'suelo'     => 'photo-1457530378978-8bac673b8062', // plantas verdes sobre la tierra
        'brotes'    => 'photo-1466692476868-aef1dfb1e735', // brotes en foco selectivo
        'girasoles' => 'photo-1599622752960-ff58212586fa', // campo de girasoles
        'tulipanes' => 'photo-1559150180-a0b6c0a1193d',    // campo de flores de colores
    ];
    $id = $ids[$key] ?? $ids['suelo'];
    return 'https://images.unsplash.com/' . $id . '?auto=format&fit=crop&q=75&w=' . $width;
}

/** Íconos SVG de trazo (24x24) usados en la interfaz. */
function icon(string $name, int $size = 24): string
{
    $paths = [
        'temperatura' => '<path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"/>',
        'humedad_ambiente' => '<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',
        'humedad_suelo' => '<path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>',
        'co2' => '<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>',
        'wifi' => '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
        'key' => '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/>',
    ];
    $inner = $paths[$name] ?? '';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size
        . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
        . 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $inner . '</svg>';
}
