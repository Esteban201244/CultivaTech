<?php
declare(strict_types=1);

/**
 * Controlador base: render de vistas, redirecciones, JSON y guardas de acceso.
 */
abstract class Controller
{
    protected function render(string $view, array $data = []): void
    {
        $file = dirname(__DIR__) . '/views/' . $view . '.php';
        if (!is_file($file)) {
            throw new RuntimeException("Vista no encontrada: {$view}");
        }
        extract($data, EXTR_SKIP);
        require $file;
    }

    protected function redirect(string $path): never
    {
        header('Location: ' . url($path));
        exit;
    }

    protected function json(array $payload, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /** Exige sesión iniciada; devuelve el usuario actual. */
    protected function requireAuth(): array
    {
        if (!Session::check()) {
            $this->redirect('login.php');
        }
        return Session::user();
    }

    /** Evita que un usuario con sesión vea login/registro. */
    protected function requireGuest(): void
    {
        if (Session::check()) {
            $this->redirect('dashboard.php');
        }
    }

    protected function isPost(): bool
    {
        return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
    }
}
