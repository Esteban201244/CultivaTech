/* CultivaTech · CRUD de lecturas
 * Abre los diálogos de agregar, editar y eliminar, y precarga sus campos.
 * El envío es un formulario normal (POST a lecturas.php), así que el
 * servidor valida de nuevo todo lo que llega.
 */
(function () {
    'use strict';

    var readingDlg = document.getElementById('reading-dialog');
    var deleteDlg = document.getElementById('delete-dialog');
    var deleteAllDlg = document.getElementById('delete-all-dialog');
    if (!readingDlg || typeof readingDlg.showModal !== 'function') { return; }

    var form = readingDlg.querySelector('form');
    var FIELDS = ['fecha', 'temperatura', 'humedad_ambiente', 'humedad_suelo', 'co2'];

    function setField(name, value) {
        var input = form.elements[name];
        if (input) { input.value = value; }
    }

    /* ---------- Agregar ---------- */

    function openCreate() {
        form.reset();
        setField('action', 'create');
        setField('id', '');
        setField('fecha', readingDlg.getAttribute('data-now') || '');
        document.getElementById('reading-title').textContent = 'Agregar lectura';
        document.getElementById('reading-submit').textContent = 'Guardar lectura';
        readingDlg.showModal();
        form.elements.temperatura.focus();
    }

    /* ---------- Editar ---------- */

    function openEdit(btn) {
        form.reset();
        setField('action', 'update');
        setField('id', btn.getAttribute('data-id'));
        FIELDS.forEach(function (name) {
            setField(name, btn.getAttribute('data-' + name) || '');
        });
        document.getElementById('reading-title').textContent = 'Editar lectura';
        document.getElementById('reading-submit').textContent = 'Guardar cambios';
        readingDlg.showModal();
        form.elements.temperatura.focus();
    }

    /* ---------- Eliminar ---------- */

    function openDelete(btn) {
        deleteDlg.querySelector('input[name="id"]').value = btn.getAttribute('data-id');
        document.getElementById('delete-text').textContent =
            'Se eliminará la lectura del ' + btn.getAttribute('data-fecha-label') +
            '. Esta acción no se puede deshacer.';
        deleteDlg.showModal();
    }

    /* ---------- Enlaces ---------- */

    document.querySelectorAll('[data-open="create"]').forEach(function (b) {
        b.addEventListener('click', openCreate);
    });
    document.querySelectorAll('[data-open="delete-all"]').forEach(function (b) {
        b.addEventListener('click', function () { deleteAllDlg.showModal(); });
    });
    document.querySelectorAll('[data-edit]').forEach(function (b) {
        b.addEventListener('click', function () { openEdit(b); });
    });
    document.querySelectorAll('[data-delete]').forEach(function (b) {
        b.addEventListener('click', function () { openDelete(b); });
    });

    // Cancelar y clic fuera del diálogo
    document.querySelectorAll('dialog.modal').forEach(function (dlg) {
        dlg.querySelectorAll('[data-close]').forEach(function (b) {
            b.addEventListener('click', function () { dlg.close(); });
        });
        dlg.addEventListener('click', function (ev) {
            if (ev.target === dlg) { dlg.close(); }
        });
    });

    // Tras guardar o eliminar, el mensaje queda visible al llegar a la tabla
    if (window.location.hash === '#lecturas') {
        var panel = document.getElementById('lecturas');
        if (panel) { panel.scrollIntoView({ block: 'start' }); }
    }
})();
