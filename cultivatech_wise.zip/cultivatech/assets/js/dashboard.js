/* CultivaTech · panel de monitoreo
 * - Dibuja las tendencias (sparklines) con SVG.
 * - Refresca los datos cada 15 s desde api/dashboard.php.
 * - Copiar / mostrar la clave API.
 */
(function () {
    'use strict';

    var REFRESH_MS = 15000;
    var root = document.querySelector('.dash');
    var dataNode = document.getElementById('ct-data');
    if (!root || !dataNode) { return; }

    var endpoint = root.getAttribute('data-endpoint');
    var loginUrl = root.getAttribute('data-login');
    var SVG_NS = 'http://www.w3.org/2000/svg';

    /* ---------- Sparkline ---------- */

    function drawSpark(svg, values) {
        while (svg.firstChild) { svg.removeChild(svg.firstChild); }
        if (!values || values.length < 2) { return; }

        var w = 160, h = 44, pad = 4;
        var min = Math.min.apply(null, values);
        var max = Math.max.apply(null, values);
        var span = (max - min) || 1;

        var pts = values.map(function (v, i) {
            var x = (i / (values.length - 1)) * w;
            var y = h - pad - ((v - min) / span) * (h - pad * 2);
            return [x, y];
        });

        var line = pts.map(function (p, i) {
            return (i === 0 ? 'M' : 'L') + p[0].toFixed(1) + ' ' + p[1].toFixed(1);
        }).join(' ');

        var area = document.createElementNS(SVG_NS, 'path');
        area.setAttribute('class', 'spark__area');
        area.setAttribute('d', line + ' L' + w + ' ' + h + ' L0 ' + h + ' Z');

        var path = document.createElementNS(SVG_NS, 'path');
        path.setAttribute('class', 'spark__line');
        path.setAttribute('d', line);

        svg.appendChild(area);
        svg.appendChild(path);
    }

    /* ---------- Render ---------- */

    function setText(scope, role, text) {
        var el = scope.querySelector('[data-role="' + role + '"]');
        if (el && el.textContent !== text) { el.textContent = text; }
    }

    function render(data) {
        (data.metrics || []).forEach(function (m) {
            var card = root.querySelector('.metric[data-key="' + m.key + '"]');
            if (!card) { return; }
            card.setAttribute('data-status', m.status);
            setText(card, 'display', m.display);
            setText(card, 'status', m.status_label);
            setText(card, 'min', m.min);
            setText(card, 'avg', m.avg);
            setText(card, 'max', m.max);
            drawSpark(card.querySelector('[data-role="spark"]'), m.series);
        });

        var label = document.getElementById('updated-label');
        if (label) {
            label.textContent = data.has_data
                ? 'Última lectura: ' + data.updated_label
                : 'Esperando la primera lectura';
        }

        var empty = document.getElementById('empty-state');
        if (empty && data.has_data) { empty.parentNode.removeChild(empty); }

    }

    /* ---------- Actualización automática ---------- */

    function refresh() {
        if (document.hidden) { return; }
        fetch(endpoint, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
            .then(function (res) {
                if (res.status === 401) { window.location.href = loginUrl; return null; }
                return res.ok ? res.json() : null;
            })
            .then(function (data) { if (data && data.ok) { render(data); } })
            .catch(function () { /* sin conexión: se reintenta en el siguiente ciclo */ });
    }

    try {
        render(JSON.parse(dataNode.textContent));
    } catch (e) { /* los valores ya vienen renderizados desde PHP */ }

    setInterval(refresh, REFRESH_MS);
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) { refresh(); }
    });

    /* ---------- Clave API: copiar / mostrar ---------- */

    document.querySelectorAll('[data-copy]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.querySelector(btn.getAttribute('data-copy'));
            if (!input) { return; }
            var original = btn.textContent;
            var done = function () {
                btn.textContent = 'Copiado';
                setTimeout(function () { btn.textContent = original; }, 1600);
            };
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(input.value).then(done);
            } else {
                var prevType = input.type;
                input.type = 'text';
                input.select();
                try { document.execCommand('copy'); done(); } catch (err) { /* ignorar */ }
                input.type = prevType;
                input.setSelectionRange(0, 0);
            }
        });
    });

    document.querySelectorAll('[data-toggle]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.querySelector(btn.getAttribute('data-toggle'));
            if (!input) { return; }
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Ocultar' : 'Mostrar';
        });
    });
})();
