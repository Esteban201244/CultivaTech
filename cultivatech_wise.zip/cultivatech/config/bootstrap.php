<?php
declare(strict_types=1);

/**
 * Punto de arranque común: configuración, núcleo, modelos y controladores.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../core/helpers.php';
require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Session.php';
require_once __DIR__ . '/../core/Controller.php';

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/SensorReading.php';

require_once __DIR__ . '/../controllers/HomeController.php';
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/DashboardController.php';
require_once __DIR__ . '/../controllers/ReadingController.php';
require_once __DIR__ . '/../controllers/ApiController.php';

// Cabeceras de seguridad básicas
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Mensaje genérico ante errores no controlados (el detalle va al log de PHP)
set_exception_handler(static function (Throwable $e): void {
    error_log('[CultivaTech] ' . $e->getMessage() . ' en ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    if (APP_DEBUG) {
        echo '<pre>' . htmlspecialchars((string) $e, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
    $isApi = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
    if ($isApi) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Error interno del servidor.']);
    } else {
        echo 'Ocurrió un error inesperado. Verifica que MySQL esté activo y que importaste database.sql.';
    }
});
