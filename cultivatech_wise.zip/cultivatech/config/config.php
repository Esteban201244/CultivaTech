<?php
declare(strict_types=1);

/**
 * Configuración global de CultivaTech.
 * Valores por defecto de XAMPP: usuario root sin contraseña.
 */

date_default_timezone_set('America/Bogota');

const APP_NAME  = 'CultivaTech';
const APP_DEBUG = false; // true solo mientras desarrollas

const DB_HOST    = '127.0.0.1';
const DB_PORT    = '3306';
const DB_NAME    = 'cultivatech';
const DB_USER    = 'root';
const DB_PASS    = '';
const DB_CHARSET = 'utf8mb4';

// Manejo de errores
error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');

/**
 * BASE_URL: ruta web de la carpeta del proyecto respecto a htdocs.
 * Si lo copias a htdocs/cultivatech => "/cultivatech". Si es la raíz => "".
 */
(static function (): void {
    $root = rtrim(str_replace('\\', '/', (string) realpath($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
    $app  = rtrim(str_replace('\\', '/', dirname(__DIR__)), '/');
    $base = '';
    if ($root !== '' && strncasecmp($app, $root, strlen($root)) === 0) {
        $base = substr($app, strlen($root));
    }
    define('BASE_URL', $base);
})();

/**
 * Definición de los 4 sensores y sus umbrales.
 *  - optimo:    rango ideal para la mayoría de cultivos de hoja y hortalizas
 *  - aceptable: fuera del óptimo pero sin riesgo inmediato (estado "atención")
 *  - fuera de "aceptable" => estado "crítico"
 * Ajusta estos valores según el cultivo.
 */
const SENSORS = [
    'temperatura' => [
        'label'    => 'Temperatura ambiental',
        'unit'     => '°C',
        'decimals' => 1,
        'optimo'   => [18, 30],
        'aceptable'=> [10, 35],
    ],
    'humedad_ambiente' => [
        'label'    => 'Humedad ambiental',
        'unit'     => '%',
        'decimals' => 1,
        'optimo'   => [50, 80],
        'aceptable'=> [35, 90],
    ],
    'humedad_suelo' => [
        'label'    => 'Humedad del suelo',
        'unit'     => '%',
        'decimals' => 1,
        'optimo'   => [40, 70],
        'aceptable'=> [25, 85],
    ],
    'co2' => [
        'label'    => 'Nivel de CO₂',
        'unit'     => 'ppm',
        'decimals' => 0,
        'optimo'   => [350, 1000],
        'aceptable'=> [300, 1500],
    ],
];

// Rangos físicos válidos al recibir datos desde el dispositivo
const SENSOR_LIMITS = [
    'temperatura'      => [-40, 80],
    'humedad_ambiente' => [0, 100],
    'humedad_suelo'    => [0, 100],
    'co2'              => [250, 10000],
];
