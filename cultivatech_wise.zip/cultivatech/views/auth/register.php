<?php
/** @var array $errors */
/** @var array $old */
$title     = 'Crear cuenta · CultivaTech';
$bodyClass = 'page-auth';
require __DIR__ . '/../partials/head.php';
?>
<main class="auth">
    <aside class="auth__side" style="background-image:url('<?= e(photo('tulipanes', 1100)) ?>')">
        <a class="brand brand--light" href="<?= e(url('index.php')) ?>" aria-label="CultivaTech, inicio">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="40" height="40">
            <span>cultiva<b>.tech</b></span>
        </a>
        <p class="auth__quote">Crea tu cuenta y empieza a leer tu cultivo.</p>
    </aside>

    <section class="auth__panel">
        <div class="auth__box">
            <h1>Crea tu cuenta</h1>
            <p class="auth__sub">Recibirás una clave personal para conectar tu dispositivo.</p>

            <?php if ($errors): ?>
                <div class="alert alert--error" role="alert">
                    <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="<?= e(url('register.php')) ?>" novalidate>
                <input type="hidden" name="csrf" value="<?= e(Session::csrfToken()) ?>">

                <label class="field">
                    <span>Nombre</span>
                    <input type="text" name="nombre" value="<?= e($old['nombre']) ?>" autocomplete="name" maxlength="80" required autofocus>
                </label>

                <label class="field">
                    <span>Correo electrónico</span>
                    <input type="email" name="email" value="<?= e($old['email']) ?>" autocomplete="email" maxlength="150" required>
                </label>

                <label class="field">
                    <span>Contraseña</span>
                    <input type="password" name="password" autocomplete="new-password" minlength="8" required aria-describedby="pw-hint">
                    <small id="pw-hint">Mínimo 8 caracteres, con letras y números.</small>
                </label>

                <label class="field">
                    <span>Repite la contraseña</span>
                    <input type="password" name="password_confirm" autocomplete="new-password" minlength="8" required>
                </label>

                <button class="btn btn--lime btn--block btn--lg" type="submit">Crear mi cuenta</button>
            </form>

            <p class="auth__alt">¿Ya tienes cuenta? <a href="<?= e(url('login.php')) ?>">Iniciar sesión</a></p>
        </div>
    </section>
</main>
<?php
$scripts = [];
require __DIR__ . '/../partials/footer.php';
