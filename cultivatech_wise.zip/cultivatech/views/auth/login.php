<?php
/** @var array $errors */
/** @var array $old */
$title     = 'Iniciar sesión · CultivaTech';
$bodyClass = 'page-auth';
require __DIR__ . '/../partials/head.php';
?>
<main class="auth">
    <aside class="auth__side" style="background-image:url('<?= e(photo('semillero', 1100)) ?>')">
        <a class="brand brand--light" href="<?= e(url('index.php')) ?>" aria-label="CultivaTech, inicio">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="40" height="40">
            <span>cultiva<b>.tech</b></span>
        </a>
        <p class="auth__quote">Entra y mira cómo está tu cultivo hoy.</p>
    </aside>

    <section class="auth__panel">
        <div class="auth__box">
            <h1>Inicia sesión</h1>
            <p class="auth__sub">Entra para ver el estado de tu cultivo.</p>

            <?php if ($errors): ?>
                <div class="alert alert--error" role="alert">
                    <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="<?= e(url('login.php')) ?>" novalidate>
                <input type="hidden" name="csrf" value="<?= e(Session::csrfToken()) ?>">

                <label class="field">
                    <span>Correo electrónico</span>
                    <input type="email" name="email" value="<?= e($old['email']) ?>" autocomplete="email" required autofocus>
                </label>

                <label class="field">
                    <span>Contraseña</span>
                    <input type="password" name="password" autocomplete="current-password" required>
                </label>

                <button class="btn btn--lime btn--block btn--lg" type="submit">Entrar a mi panel</button>
            </form>

            <p class="auth__alt">¿Aún no tienes cuenta? <a href="<?= e(url('register.php')) ?>">Crear cuenta</a></p>
        </div>
    </section>
</main>
<?php
$scripts = [];
require __DIR__ . '/../partials/footer.php';
