<?php
/** @var string $title */
/** @var string $bodyClass */
$bodyClass = $bodyClass ?? '';
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? APP_NAME) ?></title>
    <meta name="description" content="CultivaTech: monitoreo de agricultura inteligente. Temperatura, humedad y CO₂ de tu cultivo en un solo panel.">
    <meta name="theme-color" content="#163300">
    <link rel="icon" type="image/png" href="<?= e(asset('img/logo.png')) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
</head>
<body class="<?= e($bodyClass) ?>">
