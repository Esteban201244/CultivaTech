<?php
/** @var array $scripts Rutas de scripts (relativas a assets/) */
foreach (($scripts ?? []) as $script): ?>
    <script src="<?= e(asset($script)) ?>" defer></script>
<?php endforeach; ?>
</body>
</html>
