<?php
/** @var bool $logged */
?>
<header class="topbar">
    <div class="container topbar__inner">
        <a class="brand" href="<?= e(url('index.php')) ?>" aria-label="CultivaTech, inicio">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="40" height="40">
            <span>cultiva<b>.tech</b></span>
        </a>
        <nav class="pillnav" aria-label="Principal">
            <a href="#que-mide">Qué mide</a>
            <a href="#cultivo">Tu cultivo</a>
            <a href="#como-funciona">Cómo funciona</a>
        </nav>
        <div class="topbar__actions">
            <?php if (!empty($logged)): ?>
                <a class="btn btn--solid" href="<?= e(url('dashboard.php')) ?>">Ir a mi panel</a>
            <?php else: ?>
                <a class="btn btn--text" href="<?= e(url('login.php')) ?>">Iniciar sesión</a>
                <a class="btn btn--outline" href="<?= e(url('register.php')) ?>">Crear cuenta</a>
            <?php endif; ?>
        </div>
    </div>
</header>
