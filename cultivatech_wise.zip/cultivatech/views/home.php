<?php
/** @var bool $logged */
$title     = 'CultivaTech · Tus cultivos, cultivo inteligente';
$bodyClass = 'page-home';
require __DIR__ . '/partials/head.php';
require __DIR__ . '/partials/nav_public.php';
?>
<main>
    <!-- ============ Hero ============ -->
    <section class="hero">
        <div class="container hero__inner">
            <p class="tag">Smart Agriculture</p>
            <h1 class="display">Tus cultivos, cultivo inteligente.</h1>
            <p class="hero__lead">
                Reúne la temperatura, la humedad y el CO₂ de tu cultivo en un solo panel.
                Riega y ventila con datos, no con suposiciones.
            </p>
            <div class="hero__cta">
                <?php if ($logged): ?>
                    <a class="btn btn--lime btn--lg" href="<?= e(url('dashboard.php')) ?>">Ir a mi panel</a>
                <?php else: ?>
                    <a class="btn btn--lime btn--lg" href="<?= e(url('register.php')) ?>">Crear mi cuenta</a>
                    <a class="link" href="<?= e(url('login.php')) ?>">Ya tengo cuenta</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="container mosaic" aria-label="Fotografías de cultivos">
            <figure class="mosaic__item mosaic__item--a" style="background-image:url('<?= e(photo('tulipanes', 900)) ?>')" role="img" aria-label="Campo de flores de colores"></figure>
            <figure class="mosaic__item mosaic__item--b" style="background-image:url('<?= e(photo('semillero', 1000)) ?>')" role="img" aria-label="Plántulas creciendo en macetas">
                <figcaption class="reading">
                    <span class="reading__label">Humedad del suelo</span>
                    <span class="reading__value">55,4 <small>%</small></span>
                    <span class="chip chip--lime">Óptimo</span>
                </figcaption>
            </figure>
            <figure class="mosaic__item mosaic__item--c" style="background-image:url('<?= e(photo('girasoles', 900)) ?>')" role="img" aria-label="Campo de girasoles"></figure>
        </div>
    </section>

    <!-- ============ Qué mide ============ -->
    <section class="section section--mist" id="que-mide">
        <div class="container">
            <div class="section__head">
                <h2 class="h-lg">Cuatro lecturas que cambian cómo decides</h2>
                <p>Cada sensor responde una pregunta concreta de tu cultivo.</p>
            </div>
            <div class="measures">
                <article class="measure">
                    <span class="measure__icon"><?= icon('temperatura', 26) ?></span>
                    <h3>Temperatura ambiental</h3>
                    <p>Detecta el calor o el frío que frenan el crecimiento antes de que se note en las hojas.</p>
                </article>
                <article class="measure">
                    <span class="measure__icon"><?= icon('humedad_ambiente', 26) ?></span>
                    <h3>Humedad ambiental</h3>
                    <p>Controla el aire húmedo que favorece los hongos y el aire seco que estresa la planta.</p>
                </article>
                <article class="measure">
                    <span class="measure__icon"><?= icon('humedad_suelo', 26) ?></span>
                    <h3>Humedad del suelo</h3>
                    <p>Un sensor capacitivo te dice cuándo regar y cuándo parar, sin escarbar la tierra.</p>
                </article>
                <article class="measure">
                    <span class="measure__icon"><?= icon('co2', 26) ?></span>
                    <h3>Niveles de CO₂</h3>
                    <p>Avisa cuando el invernadero necesita ventilación para que las plantas sigan respirando bien.</p>
                </article>
            </div>
        </div>
    </section>

    <!-- ============ Tu cultivo (foto + texto) ============ -->
    <section class="section" id="cultivo">
        <div class="container split">
            <div class="split__media">
                <div class="photo photo--tall" style="background-image:url('<?= e(photo('manos', 900)) ?>')" role="img" aria-label="Manos sosteniendo una plántula"></div>
                <div class="photo photo--round" style="background-image:url('<?= e(photo('brotes', 700)) ?>')" role="img" aria-label="Brotes jóvenes en la tierra"></div>
            </div>
            <div class="split__copy">
                <h2 class="h-lg">Cuida cada planta como si estuvieras ahí</h2>
                <p>
                    Flores, hortalizas o plántulas: todas piden el mismo cuidado. Con CultivaTech ves cómo
                    está el aire y la tierra en tiempo real y reaccionas a tiempo.
                </p>
                <ul class="chips" aria-label="Para qué cultivos sirve">
                    <li class="chip">Flores</li>
                    <li class="chip">Hortalizas</li>
                    <li class="chip">Semilleros</li>
                    <li class="chip">Invernaderos</li>
                    <li class="chip">Huertas urbanas</li>
                </ul>
            </div>
        </div>
    </section>

    <!-- ============ Cómo funciona ============ -->
    <section class="section section--ink" id="como-funciona">
        <div class="container">
            <div class="section__head">
                <h2 class="h-lg">De la parcela a tu pantalla en tres pasos</h2>
            </div>
            <ol class="steps">
                <li>
                    <h3>Instala los sensores</h3>
                    <p>Conecta tu dispositivo con los sensores de clima, suelo y CO₂ en el cultivo.</p>
                </li>
                <li>
                    <h3>Envía las lecturas</h3>
                    <p>Cada cuenta tiene una clave personal. Con ella, tu dispositivo manda los datos por internet.</p>
                </li>
                <li>
                    <h3>Decide con el panel</h3>
                    <p>Mira el valor actual, la tendencia y si cada medida está en rango óptimo, en atención o en estado crítico.</p>
                </li>
            </ol>
        </div>
    </section>

    <!-- ============ CTA final ============ -->
    <section class="section section--cta">
        <div class="container">
            <div class="ctacard" style="background-image:url('<?= e(photo('girasoles', 1400)) ?>')">
                <div class="ctacard__body">
                    <h2 class="h-lg">Empieza a leer tu cultivo hoy</h2>
                    <p>Crea tu cuenta, carga datos de demostración y conoce el panel en un minuto.</p>
                    <div class="hero__cta">
                        <?php if ($logged): ?>
                            <a class="btn btn--lime btn--lg" href="<?= e(url('dashboard.php')) ?>">Ir a mi panel</a>
                        <?php else: ?>
                            <a class="btn btn--lime btn--lg" href="<?= e(url('register.php')) ?>">Crear mi cuenta</a>
                            <a class="link link--light" href="<?= e(url('login.php')) ?>">Iniciar sesión</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<footer class="footer">
    <div class="container footer__inner">
        <span>© <?= e(date('Y')) ?> CultivaTech · Smart Agriculture</span>
        <span>Monitoreo inteligente para cultivos.</span>
    </div>
</footer>
<?php
$scripts = [];
require __DIR__ . '/partials/footer.php';
