<?php
/** @var array  $user */
/** @var string $apiKey */
/** @var array  $summary */
/** @var array  $readings */
/** @var array|null $flash */
/** @var string $nowInput */
/** @var string $endpoint */
/** @var string $live */
$title     = 'Mi panel · CultivaTech';
$bodyClass = 'page-dashboard';
require __DIR__ . '/partials/head.php';

$firstName = explode(' ', trim($user['nombre']))[0];
$embedded  = json_encode(
    $summary,
    JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
$csrf     = Session::csrfToken();
$crudUrl  = url('lecturas.php');
$page     = (int) $readings['page'];
$pages    = (int) $readings['pages'];
$total    = (int) $readings['total'];
$fields   = ['temperatura', 'humedad_ambiente', 'humedad_suelo', 'co2'];
?>
<header class="dash-top">
    <div class="container dash-top__inner">
        <a class="brand" href="<?= e(url('index.php')) ?>" aria-label="CultivaTech, inicio">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" width="40" height="40">
            <span>cultiva<b>.tech</b></span>
        </a>
        <div class="dash-top__user">
            <span class="dash-top__name"><?= e($user['nombre']) ?></span>
            <form method="post" action="<?= e(url('logout.php')) ?>">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <button class="btn btn--outline" type="submit"><?= icon('logout', 18) ?> Cerrar sesión</button>
            </form>
        </div>
    </div>
</header>

<main class="container dash" data-endpoint="<?= e($live) ?>" data-login="<?= e(url('login.php')) ?>">
    <section class="dash-hero">
        <div class="dash-hero__body">
            <p class="tag tag--lime">Panel de cultivo</p>
            <h1>Hola, <?= e($firstName) ?></h1>
            <p class="dash__sub">Así está tu cultivo ahora mismo.</p>
            <p class="live" aria-live="polite">
                <span class="live__dot" aria-hidden="true"></span>
                <span id="updated-label">
                    <?= $summary['has_data'] ? 'Última lectura: ' . e($summary['updated_label']) : 'Esperando la primera lectura' ?>
                </span>
            </p>
        </div>
        <div class="dash-hero__photo" style="background-image:url('<?= e(photo('brotes', 900)) ?>')" role="img" aria-label="Brotes jóvenes en la tierra"></div>
    </section>

    <?php if (!$summary['has_data']): ?>
        <section class="empty" id="empty-state">
            <div>
                <h2>Todavía no llegan lecturas</h2>
                <p>Agrega una lectura a mano, conecta tu dispositivo con la clave que aparece más abajo, o carga datos de demostración para explorar el panel.</p>
            </div>
            <form method="post" action="<?= e(url('dashboard.php')) ?>">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <button class="btn btn--lime btn--lg" type="submit">Cargar datos de demostración</button>
            </form>
        </section>
    <?php endif; ?>

    <section class="metrics" aria-label="Métricas del cultivo">
        <?php foreach ($summary['metrics'] as $m): ?>
            <article class="metric" data-key="<?= e($m['key']) ?>" data-status="<?= e($m['status']) ?>">
                <header class="metric__head">
                    <span class="metric__icon"><?= icon($m['key'], 22) ?></span>
                    <h2><?= e($m['label']) ?></h2>
                </header>

                <p class="metric__value">
                    <span data-role="display"><?= e($m['display']) ?></span>
                    <small><?= e($m['unit']) ?></small>
                </p>
                <p class="badge" data-role="status"><?= e($m['status_label']) ?></p>

                <svg class="spark" data-role="spark" viewBox="0 0 160 44" preserveAspectRatio="none" role="img"
                     aria-label="Tendencia de <?= e(mb_strtolower($m['label'])) ?>"></svg>

                <dl class="metric__stats">
                    <div><dt>Mínimo</dt><dd data-role="min"><?= e($m['min']) ?></dd></div>
                    <div><dt>Promedio</dt><dd data-role="avg"><?= e($m['avg']) ?></dd></div>
                    <div><dt>Máximo</dt><dd data-role="max"><?= e($m['max']) ?></dd></div>
                </dl>
                <p class="metric__range"><?= e($m['range_text']) ?></p>
            </article>
        <?php endforeach; ?>
    </section>

    <div class="dash__lower">
        <!-- ============ CRUD de lecturas ============ -->
        <section class="panel" id="lecturas" aria-labelledby="crud-title">
            <div class="panel__head">
                <div>
                    <h2 id="crud-title">Lecturas registradas</h2>
                    <p class="panel__text">
                        <?= e(number_format($total, 0, ',', '.')) ?> <?= $total === 1 ? 'lectura' : 'lecturas' ?> · las más recientes primero
                    </p>
                </div>
                <div class="panel__actions">
                    <button type="button" class="btn btn--lime" data-open="create">Agregar lectura</button>
                    <?php if ($total > 0): ?>
                        <button type="button" class="btn btn--danger-soft" data-open="delete-all">Eliminar todas</button>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($flash): ?>
                <div class="alert alert--<?= $flash['type'] === 'ok' ? 'ok' : 'error' ?>"
                     role="<?= $flash['type'] === 'ok' ? 'status' : 'alert' ?>">
                    <p><?= e($flash['message']) ?></p>
                </div>
            <?php endif; ?>

            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Fecha</th>
                            <th scope="col">Temp. (°C)</th>
                            <th scope="col">Hum. aire (%)</th>
                            <th scope="col">Hum. suelo (%)</th>
                            <th scope="col">CO₂ (ppm)</th>
                            <th scope="col" class="table__actions-head">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$readings['rows']): ?>
                            <tr><td colspan="6" class="table__empty">Sin lecturas todavía. Usa «Agregar lectura» para registrar la primera.</td></tr>
                        <?php endif; ?>

                        <?php foreach ($readings['rows'] as $r): ?>
                            <tr>
                                <td><?= e($r['fecha_label']) ?></td>
                                <?php foreach ($fields as $f): ?>
                                    <td>
                                        <span class="dot dot--<?= e($r[$f]['status']) ?>" title="<?= e(SensorReading::statusLabel($r[$f]['status'])) ?>"></span>
                                        <?= e($r[$f]['display']) ?>
                                    </td>
                                <?php endforeach; ?>
                                <td class="table__actions">
                                    <button type="button" class="btn btn--soft btn--sm"
                                        data-edit
                                        data-id="<?= e($r['id']) ?>"
                                        data-fecha="<?= e($r['fecha_input']) ?>"
                                        data-temperatura="<?= e($r['temperatura']['raw']) ?>"
                                        data-humedad_ambiente="<?= e($r['humedad_ambiente']['raw']) ?>"
                                        data-humedad_suelo="<?= e($r['humedad_suelo']['raw']) ?>"
                                        data-co2="<?= e($r['co2']['raw']) ?>"
                                        aria-label="Editar la lectura del <?= e($r['fecha_label']) ?>">Editar</button>
                                    <button type="button" class="btn btn--danger-soft btn--sm"
                                        data-delete
                                        data-id="<?= e($r['id']) ?>"
                                        data-fecha-label="<?= e($r['fecha_label']) ?>"
                                        aria-label="Eliminar la lectura del <?= e($r['fecha_label']) ?>">Eliminar</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($pages > 1): ?>
                <nav class="pager" aria-label="Paginación de lecturas">
                    <?php if ($page > 1): ?>
                        <a class="btn btn--soft btn--sm" href="<?= e(url('dashboard.php?page=' . ($page - 1)) . '#lecturas') ?>">Anterior</a>
                    <?php else: ?>
                        <span class="btn btn--soft btn--sm is-disabled" aria-disabled="true">Anterior</span>
                    <?php endif; ?>

                    <span class="pager__info">Página <?= $page ?> de <?= $pages ?></span>

                    <?php if ($page < $pages): ?>
                        <a class="btn btn--soft btn--sm" href="<?= e(url('dashboard.php?page=' . ($page + 1)) . '#lecturas') ?>">Siguiente</a>
                    <?php else: ?>
                        <span class="btn btn--soft btn--sm is-disabled" aria-disabled="true">Siguiente</span>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        </section>

        <!-- ============ Conexión del dispositivo ============ -->
        <section class="panel" aria-labelledby="device-title">
            <h2 id="device-title">Conecta tu dispositivo</h2>
            <p class="panel__text">Envía un POST a este endpoint con tu clave personal en la cabecera <code>X-API-Key</code>.</p>

            <div class="copyrow">
                <label for="endpoint">Endpoint</label>
                <input id="endpoint" type="text" value="<?= e($endpoint) ?>" readonly>
                <button class="btn btn--soft" type="button" data-copy="#endpoint">Copiar</button>
            </div>

            <div class="copyrow">
                <label for="apikey">Tu clave API</label>
                <input id="apikey" type="password" value="<?= e($apiKey) ?>" readonly>
                <button class="btn btn--soft" type="button" data-toggle="#apikey">Mostrar</button>
                <button class="btn btn--soft" type="button" data-copy="#apikey">Copiar</button>
            </div>
            <p class="panel__warn">Trata la clave como una contraseña: quien la tenga puede enviar lecturas a tu cuenta.</p>

            <details class="example">
                <summary>Ver ejemplo de envío</summary>
<pre><code>curl -X POST "<?= e($endpoint) ?>" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: TU_CLAVE_API" \
  -d '{"temperatura":24.8,"humedad_ambiente":68.2,"humedad_suelo":55.4,"co2":612}'</code></pre>
            </details>
        </section>
    </div>
</main>

<!-- ============ Diálogo: agregar / editar ============ -->
<dialog class="modal" id="reading-dialog" data-now="<?= e($nowInput) ?>" aria-labelledby="reading-title">
    <form method="post" action="<?= e($crudUrl) ?>" class="modal__form">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="action" value="create">
        <input type="hidden" name="id" value="">
        <input type="hidden" name="page" value="<?= $page ?>">

        <h2 id="reading-title">Agregar lectura</h2>

        <div class="modal__grid">
            <label class="field field--full">
                <span>Fecha y hora</span>
                <input type="datetime-local" name="fecha" max="<?= e($nowInput) ?>" required>
            </label>

            <?php foreach (SENSORS as $key => $def):
                [$min, $max] = SENSOR_LIMITS[$key]; ?>
                <label class="field">
                    <span><?= e($def['label']) ?> (<?= e($def['unit']) ?>)</span>
                    <input type="number" name="<?= e($key) ?>" inputmode="decimal"
                           step="<?= $def['decimals'] === 0 ? '1' : '0.01' ?>"
                           min="<?= e($min) ?>" max="<?= e($max) ?>" required>
                    <small>Entre <?= e($min) ?> y <?= e($max) ?></small>
                </label>
            <?php endforeach; ?>
        </div>

        <div class="modal__actions">
            <button type="button" class="btn btn--outline" data-close>Cancelar</button>
            <button type="submit" class="btn btn--lime" id="reading-submit">Guardar lectura</button>
        </div>
    </form>
</dialog>

<!-- ============ Diálogo: eliminar una lectura ============ -->
<dialog class="modal modal--sm" id="delete-dialog" aria-labelledby="delete-title">
    <form method="post" action="<?= e($crudUrl) ?>" class="modal__form">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="">
        <input type="hidden" name="page" value="<?= $page ?>">

        <h2 id="delete-title">¿Eliminar esta lectura?</h2>
        <p class="modal__text" id="delete-text">Esta acción no se puede deshacer.</p>

        <div class="modal__actions">
            <button type="button" class="btn btn--outline" data-close>Cancelar</button>
            <button type="submit" class="btn btn--danger">Eliminar lectura</button>
        </div>
    </form>
</dialog>

<!-- ============ Diálogo: eliminar todas ============ -->
<dialog class="modal modal--sm" id="delete-all-dialog" aria-labelledby="delete-all-title">
    <form method="post" action="<?= e($crudUrl) ?>" class="modal__form">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="action" value="delete_all">
        <input type="hidden" name="page" value="1">

        <h2 id="delete-all-title">¿Eliminar todas las lecturas?</h2>
        <p class="modal__text">
            Se borrarán las <?= e(number_format($total, 0, ',', '.')) ?> lecturas de tu cuenta.
            Esta acción no se puede deshacer.
        </p>

        <div class="modal__actions">
            <button type="button" class="btn btn--outline" data-close>Cancelar</button>
            <button type="submit" class="btn btn--danger">Eliminar todas</button>
        </div>
    </form>
</dialog>

<script type="application/json" id="ct-data"><?= $embedded ?></script>
<?php
$scripts = ['js/dashboard.js', 'js/readings.js'];
require __DIR__ . '/partials/footer.php';
